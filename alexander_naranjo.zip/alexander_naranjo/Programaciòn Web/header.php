<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- header -->
<header class="banner" nav>
<ul class="menuSuperior">
<li><a href="index.php"> Home </a> </li>
<li><a href="tienda.php"> Tienda </a> </li>
<li><a href="Contacto.php"> Contacto </a></li>
<li><a href="nosotros.php"> Nosotros </a> </li>


</ul>
</nav>

<span class="titulo"> Casa Alexander </span>

</header>
</body>
</html>