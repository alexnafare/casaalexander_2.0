<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Casa Alexander </title>
<link rel="stylesheet" href="Estilos.css">
</head>

<?php include ('header.php')?>
<body>



<section class="contenido">

<p> Casa Alexander nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
convertiría en un sinónimo del buen comer. Lo llamaron “Casa Alexander”.

Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
logrando distinguir el verdadero sabor de la cocina italiana, Casa Alexander se ha convertido en un clásico
de Buenos Aires.

Dentro de su completa carta, donde las pastas son protagonistas por excelencia, encontrará una amplia
variedad de opciones apta para los paladares más exigentes.

Casa Alexander nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
convertiría en un sinónimo del buen comer. Lo llamaron “Casa Alexander”.

</p>
<section class="sucursales">    
<?php
    $texto= 'Nuestras sucursales';

    ?>
    <h2> <?php echo $texto;?> </h2>
</section>

<div class="local">
<img src="./img/local4.jpg" alt="Sucursal Mar del Plata" class="bordesredondeados">
<img src="./img/local5.jpg" alt="Sucursal CABA" class="bordesredondeados">
<img src="./img/local6.jpg" alt="Sucursal Salta " class="bordesredondeados">


</div>
</section>

<footer>
<div class="bloqueFooter">
<div>
<h4 class="tituloFooter"> Nuestro sitio </h4>
<ul class="menuFooter">
<li> <a href="index.html"> Home</a> </li>
<li><a href="tienda.php"> Tienda</a> </li>
<li><a href="sobrenosotros.php"> Sobre Nosotros</a> </li>
<li><a href="https://www.linkedin.com/in/alexander-naranjo/"> Contactanos </a> </li>
</ul>

</div>
<div>
<h4 class="tituloFooter"> Seguinos </h4>
<ul class="menuFooter">
<li> <a href="https://es-la.facebook.com/"> Facebook </a> </li>
<li><a href="https://www.instagram.com/alexanderjnf_/"> Instagram </a> </li>
<li><a href="https://twitter.com/"> Twitter </a> </li>
<li><a href="https://www.linkedin.com/in/alexander-naranjo/"> Linkedin </a> </li>

</ul>

</div>
<div>
<h4 class="tituloFooter"> Trabajá con nosotros </h4>
<ul class="menuFooter">
<li> <a href="cv.html"> Enviar CV </a> </li>

</ul>

</div>
</div>
<div class="creditoFinal"> Desarrollado por: Alexander Naranjo </div>
</footer>

<h1> </h1>
<h2> </h2>
<h2> </h2>
<h3> </h3>
<section>
<hr>





</body>

</html>