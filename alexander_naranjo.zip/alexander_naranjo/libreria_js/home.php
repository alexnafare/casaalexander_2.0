<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>


    <h1> Bienvenidos a Casa Alexander </h1>
    <section class="contenido">
        <?php 
        $titulo= 'Nuestros productos';
        $elaboracion= '100% Casera';
        $unidades = 6;
?>

<h2> <?php echo $titulo;?> </h2>
<ul>
    <li> Elaboración: <?php echo $elaboracion; ?> </li>
    <li> Unidades: <?php echo $unidades; ?> </li>
</ul>    
</section>

</body>
</html>