<!DOCTYPE html>
<html lang="en">
    <head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width", initial>
<title> Sobre nosotros </title>
<link rel="stylesheet" href="Estilos.css">

    </head>
<body>

<header class="banner" nav>
<ul class="menuSuperior">
<li><a href="index.php"> Volver al inicio </a> </li>

</ul>
</nav>

<span class="titulo"> Casa Alexander </span>

</header>
        <h1 class="titulo-sobrenosotros"> Un poco de nuestra historia </h1>



<section class="contenido">

<p> Casa Alexander nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
convertiría en un sinónimo del buen comer. Lo llamaron “Casa Alexander”.

Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
logrando distinguir el verdadero sabor de la cocina italiana, Casa Alexander se ha convertido en un clásico
de Buenos Aires.

Dentro de su completa carta, donde las pastas son protagonistas por excelencia, encontrará una amplia
variedad de opciones apta para los paladares más exigentes.

Casa Alexander nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
convertiría en un sinónimo del buen comer. Lo llamaron “Casa Alexander”.

Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
logrando distinguir el verdadero sabor de la cocina italiana, Casa Alexander se ha convertido en un clásico
de Buenos Aires.

Dentro de su completa carta, donde las pastas son protagonistas por excelencia, encontrará una amplia
variedad de opciones apta para los paladares más exigentes.
</p>

</section>
<body>

</html>