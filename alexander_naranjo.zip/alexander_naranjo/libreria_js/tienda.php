<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Tienda </title>
    <link rel="stylesheet" href="Estilos.css">
</head>

<body>
<header class="banner" nav>
<ul class="menuSuperior">
<li><a href="index.php"> Volver al inicio </a> </li>

</ul>
</nav>

<span class="titulo"> Casa Alexander Jose. </span>

</header>

    <main>
        <h1 class="titulo-tienda"> Nuestros productos disponibles </h1>
        <section class="fondo-tienda">

</section>

<div class="localtienda">

            <div>
            <img src="img/pasta.jpg" alt="Fideos imagen" class="bordesredondeados">
            <p class="descripcion">  Pasta con cherris </p>
        
            <p class="precio"> Precio: $499,00 </p>
            <button class="boton"> Agregar </button>
        </div>
        <div>
            <img src="img/pasta1.jpg" alt="Fideos imagen" class="bordesredondeados">
            <p class="descripcion">  Fideos caseros </p>
        
            <p class="precio"> Precio: $399,00 </p>
            <button class="boton"> Agregar </button>
        </div>
        <div>
            <img src="img/pasta3.jpg" alt="Fideos imagen" class="bordesredondeados">
            <p class="descripcion">  Pasta con carne </p>
        
            <p class="precio"> Precio: $349,00 </p>
            <button class="boton"> Agregar </button>
        </div>
        <div>
            <img src="img/pasta4.jpg" alt="Fideos imagen"class="bordesredondeados">
            <p class="descripcion">  Fideos caseros </p>
        
            <p class="precio"> Precio: $499,00 </p>
            <button class="boton"> Agregar </button>
        </div>
        <div>
            <img src="img/pasta5.jpg" alt="Fideos imagen" class="bordesredondeados">
            <p class="descripcion">  Fideos caseros </p>
        
            <p class="precio"> Precio: $389,00 </p>
            <button class="boton"> Agregar </button>
        </div>
        <div>
            <img src="img/pasta6.jpg" alt="Fideos imagen" class="bordesredondeados">
            <p class="descripcion">  Fideos caseros </p>
        
            <p class="precio"> Precio; $459,00 </p>
            <button class="boton"> Agregar </button>
        </div>
        <div>
            <img src="img/pasta7.jpg" alt="Fideos imagen" class="bordesredondeados">
            <p class="descripcion">  Fideos caseros </p>
        
            <p class="precio"> Precio; $549,00 </p>
            <button class="boton"> Agregar </button>
        </div>

        </div>
</section>
<footer>
<div class="bloquefooter">
<div>
<h4 class="tituloFooter"> ¡Esperamos que vuelvas! </h4>


</footer>
    </main>
    
</body>
</html>