<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosotros</title>
    <link rel="stylesheet" href="Estilos.css">
</head>

<?php include ('header.php')?>
<body>


<section> 
<div class="boton_nosotros">
    <ul>
        <li> <a href="nosotros.php?nombre=an"> Alexander Naranjo </a> </li>
        <li> <a href="nosotros.php?nombre=rc"> Roberto Champagner </a> </li>
        <li> <a href="nosotros.php?nombre=gn"> Gialeane Naranjo </a> </li>
        <li> <a href="nosotros.php?nombre=ef"> Elena Farelo </a> </li>
        <li> <a href="nosotros.php?nombre=ag"> Alejandra Gavotti </a> </li>

    </ul>
    </div>

<?php

    if(isset($_GET['nombre'])){

        switch ($_GET['nombre']) {

    case 'an':
        $nombre='Alexander Naranjo' ;
        $cargo= 'CEO' ;
        $info= 'Alexander nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
        tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
        convertiría en un sinónimo del buen comer. Lo llamaron “Casa Alexander”.
        Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
        calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
        logrando distinguir el verdadero sabor de la cocina italiana, Casa Alexander se ha convertido en un clásico
        de Buenos Aires.
        Dentro de su completa carta, donde las pastas son protagonistas por excelencia, encontrará una amplia
        variedad de opciones apta para los paladares más exigentes.
        Casa Alexander nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
        tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
        convertiría en un sinónimo del buen comer. Lo llamaron “Casa Alexander”.';
        $img = 'img/persona1.jpg';
        break;

        case 'rc':
            $nombre='Roberto Champagner' ;
            $cargo= 'Management' ;
            $info= 'Roberto nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
            tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
            convertiría en un sinónimo del buen comer. Lo llamaron Roberto.
            Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
            calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
            logrando distinguir el verdadero sabor de la cocina italiana, Roberto se ha convertido en un clásico
            de Buenos Aires.';
            $img= 'img/persona2.jpg';
            break;

    case 'gn':
                $nombre='Gialeane Naranjo' ;
                $cargo= 'Ventas' ;
                $info= 'Gialeane nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
                tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
                convertiría en un sinónimo del buen comer. Lo llamaron Roberto.
                Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
                calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
                logrando distinguir el verdadero sabor de la cocina italiana, Gialeane se ha convertido en un clásico
                de Buenos Aires.';
                $img= 'img/persona3.jpg';
                break;

    case 'ef':
                    $nombre='Elena Farelo' ;
                    $cargo= 'Tesoreria' ;
                    $info= 'Elena nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
                    tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
                    convertiría en un sinónimo del buen comer. Lo llamaron Elena.
                    Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
                    calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
                    logrando distinguir el verdadero sabor de la cocina italiana, Roberto se ha convertido en un clásico
                    de Buenos Aires.';
                    $img= 'img/persona4.jpg';
                    break;

    case 'ag':
                        $nombre='Alejandra Gavotti' ;
                        $cargo= 'Recursos Humanos' ;
                        $info= 'Alejandra nace en Roma, Italia. A mediados del siglo XX, una familia funda un humilde Restaurante en el
                        tradicional Barrio Trastévere. Su particular modo de recibir a los clientes inspiró al nombre, que se
                        convertiría en un sinónimo del buen comer. Lo llamaron Alejandra.
                        Con más de 10 años de presencia en Argentina, Casa Alexander sigue siendo fiel al estilo que le dio origen:
                        calidad, cordialidad y una esmerada atención; manteniendo intacta la esencia a lo largo de su historia y
                        logrando distinguir el verdadero sabor de la cocina italiana, Roberto se ha convertido en un clásico
                        de Buenos Aires.';
                        $img= 'img/persona5.jpg';
                        break;
            } 


        }
?>

<div class="info_nosotros">

    <h1> <?php echo $nombre; ?></h1>
    <h2> <?php echo $cargo; ?></h2>
    <p> <?php echo $info; ?></p>
    <div class="contenedor_img">
    <img src="<?php echo $img?>" alt=""> 

    </div>


</div>

</section>
</body>
</html>